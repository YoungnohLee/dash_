from waitress import serve
import app_login

serve(app_login, host = "0.0.0.0", port = 8888)